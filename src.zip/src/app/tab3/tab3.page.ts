import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { Users } from '../interfaces/users';



@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page implements OnInit{
  user: Users | null = null; // Variable para almacenar la información del usuario
  username: string | null = null; // Suponiendo que conoces el ID del usuario logueado

  
  constructor(private menucontroller: MenuController,
              private authservice:AuthService,
              private formBuilder: FormBuilder,
              private http: HttpClient, private router:Router){}

              ngOnInit() {
                this.username = sessionStorage.getItem('username'); // Obtener el nombre de usuario desde sessionStorage
                  console.log('Nombre de usuario obtenido:', this.username); // Añade esta línea para depuración
                    if (this.username) {
                  this.loadUserProfile(); // Solo cargar el perfil si se encuentra el nombre de usuario
                } else {
                console.error('No se encontró el nombre de usuario en sessionStorage');
               }
              }
              
            
              loadUserProfile() {
                this.authservice.GetUserByUsername(this.username!).subscribe(
                  (data: Users) => {
                    this.user = data; // Almacena la información del usuario en la variable
                    console.log('Información del usuario:', this.user); // Añade esta línea para depuración
                  },
                  (error) => {
                    console.error('Error al cargar el perfil del usuario', error);
                  }
                );
              }
  
  mostrarMenu(){
    this.menucontroller.enable(true);
    this.menucontroller.open('first');
  }
 }

