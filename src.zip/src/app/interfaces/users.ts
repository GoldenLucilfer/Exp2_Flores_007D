export interface Users {
    id: string;
    username: string;
    password: string;
    email:string;
    isactive: boolean;
}
//post
export interface User{
    username: string;
    password: string;
    email:string;
    isactive: boolean;
}
