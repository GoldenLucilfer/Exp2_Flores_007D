export interface Eventos {
    imageUrl: string;
    nombre: string;
    fecha: string;
    lugar: string;
    descripcion: string;
}
